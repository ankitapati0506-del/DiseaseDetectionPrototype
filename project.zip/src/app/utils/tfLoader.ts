import * as blazeface from '@tensorflow-models/blazeface';
import * as tf from '@tensorflow/tfjs';

// Singleton pattern to prevent model re-loading
let modelInstance: blazeface.BlazeFaceModel | null = null;
let modelLoadingPromise: Promise<blazeface.BlazeFaceModel> | null = null;
let isInitialized = false;

// Suppress console warnings for already registered kernels/backends in development
const originalWarn = console.warn;
const originalError = console.error;

function suppressTFWarnings() {
  console.warn = (...args: any[]) => {
    const message = args[0]?.toString() || '';
    if (
      message.includes('already registered') ||
      message.includes('already been set') ||
      message.includes('Reusing existing backend')
    ) {
      return; // Suppress these warnings
    }
    originalWarn.apply(console, args);
  };

  console.error = (...args: any[]) => {
    const message = args[0]?.toString() || '';
    if (
      message.includes('already registered') ||
      message.includes('already been set')
    ) {
      return; // Suppress these errors
    }
    originalError.apply(console, args);
  };
}

// Restore original console methods
function restoreConsole() {
  console.warn = originalWarn;
  console.error = originalError;
}

export async function loadBlazeFaceModel(): Promise<blazeface.BlazeFaceModel> {
  // If model is already loaded, return it
  if (modelInstance) {
    return modelInstance;
  }

  // If model is currently loading, wait for it
  if (modelLoadingPromise) {
    return modelLoadingPromise;
  }

  // Start loading the model
  modelLoadingPromise = (async () => {
    try {
      // Suppress TensorFlow re-registration warnings
      suppressTFWarnings();

      // Initialize TensorFlow only once
      if (!isInitialized) {
        await tf.ready();
        // Set backend preferences
        try {
          await tf.setBackend('webgl');
        } catch (e) {
          // If webgl fails, fall back to cpu
          await tf.setBackend('cpu');
        }
        isInitialized = true;
      }

      const model = await blazeface.load();
      modelInstance = model;
      
      // Restore console after a short delay
      setTimeout(restoreConsole, 100);
      
      return model;
    } catch (error) {
      modelLoadingPromise = null;
      restoreConsole();
      throw error;
    }
  })();

  return modelLoadingPromise;
}

export function getModelInstance(): blazeface.BlazeFaceModel | null {
  return modelInstance;
}