
  # AI Disease Detection Prototype

  This is a code bundle for AI Disease Detection Prototype. The original project is available at https://www.figma.com/design/pSlOGZHLLbTyBwc4I9wxfA/AI-Disease-Detection-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  